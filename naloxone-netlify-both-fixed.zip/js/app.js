
const STORAGE_KEY = "naloxone_cart_v3";
const ORDERS_KEY  = "naloxone_orders_v3";

function loadCart(){
  try{ return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch(e){ return []; }
}
function saveCart(cart){ localStorage.setItem(STORAGE_KEY, JSON.stringify(cart)); }
function money(n){ return new Intl.NumberFormat("en-GB",{style:"currency",currency:"GBP"}).format(n); }
function cartCount(cart){ return cart.reduce((s,i)=>s + (i.qty||0), 0); }
function cartSubtotal(cart){ return cart.reduce((s,i)=>s + ((i.price||0) * (i.qty||0)), 0); }

function showToast(msg){
  const toast = document.getElementById("toast");
  if(!toast) return;
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(showToast._t);
  showToast._t = setTimeout(()=>toast.classList.remove("show"), 2000);
}

async function submitNetlifyForm(formName, data){
  const params = new URLSearchParams();
  params.append("form-name", formName);
  params.append("bot-field", "");
  Object.entries(data).forEach(([k,v]) => params.append(k, typeof v === "string" ? v : JSON.stringify(v)));
  return fetch("/", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString()
  });
}

function escapeHtml(str){
  return String(str)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

function addToCart(item){
  const cart = loadCart();
  const idx = cart.findIndex(x => x.id === item.id);
  if(idx >= 0) cart[idx].qty += 1;
  else cart.push({ ...item, qty: 1 });
  saveCart(cart);
  renderCart();
  showToast(`Added: ${item.title} (${item.date})`);
}

function removeFromCart(id){
  saveCart(loadCart().filter(x => x.id !== id));
  renderCart();
}
function setQty(id, qty){
  const cart = loadCart();
  const idx = cart.findIndex(x => x.id === id);
  if(idx < 0) return;
  cart[idx].qty = Math.max(1, qty);
  saveCart(cart);
  renderCart();
}
function clearCart(){
  saveCart([]);
  renderCart();
  showToast("Cart cleared");
}

function openModal(modal){
  const overlay = document.getElementById("overlay");
  if(overlay) overlay.classList.add("open");
  modal.classList.add("open");
  document.body.style.overflow = "hidden";
}
function closeModal(modal){
  modal.classList.remove("open");
  const overlay = document.getElementById("overlay");
  if(!document.querySelector(".modal.open") && overlay) overlay.classList.remove("open");
  document.body.style.overflow = "";
}
function closeAllModals(){
  document.querySelectorAll(".modal.open").forEach(m=>m.classList.remove("open"));
  const overlay = document.getElementById("overlay");
  if(overlay) overlay.classList.remove("open");
  document.body.style.overflow = "";
}

function renderCart(){
  const cart = loadCart();
  const countEl = document.getElementById("cartCount");
  if(countEl) countEl.textContent = cartCount(cart);

  const cartEmpty = document.getElementById("cartEmpty");
  const cartList  = document.getElementById("cartList");
  if(!cartList) return;

  cartList.innerHTML = "";
  if(cartEmpty) cartEmpty.style.display = cart.length ? "none" : "block";

  cart.forEach(item => {
    const el = document.createElement("div");
    el.className = "cart-item";
    el.innerHTML = `
      <div>
        <div class="cart-item-title">${escapeHtml(item.title)} — ${escapeHtml(item.date)}</div>
        <div class="cart-item-meta">${escapeHtml(item.time)} • ${escapeHtml(item.location)}</div>
        <div class="cart-controls">
          <span class="cart-item-price">${money(item.price)}</span>
          <span class="qty">
            <button type="button" data-action="dec" data-id="${item.id}">−</button>
            <span>${item.qty}</span>
            <button type="button" data-action="inc" data-id="${item.id}">+</button>
          </span>
          <button type="button" class="remove-btn" data-action="remove" data-id="${item.id}">Remove</button>
        </div>
      </div>
      <div style="text-align:right;font-weight:900;">
        ${money(item.price * item.qty)}
      </div>
    `;
    cartList.appendChild(el);
  });

  const subtotal = cartSubtotal(cart);
  const total = subtotal;

  document.getElementById("sumItems")?.replaceChildren(document.createTextNode(String(cartCount(cart))));
  const setText = (id, t)=>{ const el=document.getElementById(id); if(el) el.textContent=t; }
  setText("sumSubtotal", money(subtotal));
  setText("sumFees", money(0));
  setText("sumTotal", money(total));

  const checkoutBtn = document.getElementById("checkoutBtn");
  if(checkoutBtn){
    checkoutBtn.disabled = cart.length === 0;
    checkoutBtn.style.opacity = cart.length === 0 ? 0.6 : 1;
    checkoutBtn.style.cursor = cart.length === 0 ? "not-allowed" : "pointer";
  }
}

function wireUp(){
  // Mobile nav
  const menuBtn = document.getElementById("menuBtn");
  const navLinks = document.getElementById("navLinks");
  menuBtn?.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", String(isOpen));
  });
  navLinks?.addEventListener("click", (e) => {
    if(e.target.tagName === "A" && navLinks.classList.contains("open")){
      navLinks.classList.remove("open");
      menuBtn.setAttribute("aria-expanded","false");
    }
  });

  // Modals
  const overlay = document.getElementById("overlay");
  overlay?.addEventListener("click", closeAllModals);
  window.addEventListener("keydown", (e) => { if(e.key === "Escape") closeAllModals(); });

  const cartModal = document.getElementById("cartModal");
  const openCartBtn = document.getElementById("openCartBtn");
  const closeCartBtn = document.getElementById("closeCartBtn");
  const clearCartBtn = document.getElementById("clearCartBtn");
  const continueBtn = document.getElementById("continueBtn");
  const viewCartButtons = document.querySelectorAll("[data-open-cart]");
  openCartBtn?.addEventListener("click", ()=>openModal(cartModal));
  closeCartBtn?.addEventListener("click", ()=>closeModal(cartModal));
  continueBtn?.addEventListener("click", ()=>closeModal(cartModal));
  clearCartBtn?.addEventListener("click", clearCart);
  viewCartButtons.forEach(b => b.addEventListener("click", ()=>openModal(cartModal)));

  const cartList = document.getElementById("cartList");
  cartList?.addEventListener("click", (e) => {
    const btn = e.target.closest("button");
    if(!btn) return;
    const action = btn.getAttribute("data-action");
    const id = btn.getAttribute("data-id");
    if(!action || !id) return;
    const cart = loadCart();
    const item = cart.find(x => x.id === id);
    if(!item) return;
    if(action === "inc") setQty(id, item.qty + 1);
    if(action === "dec") setQty(id, item.qty - 1);
    if(action === "remove") removeFromCart(id);
  });

  // Add to cart buttons
  document.querySelectorAll(".js-add").forEach(btn => {
    btn.addEventListener("click", () => {
      addToCart({
        id: btn.dataset.id,
        title: btn.dataset.title,
        date: btn.dataset.date,
        time: btn.dataset.time,
        location: btn.dataset.location,
        price: Number(btn.dataset.price || 0)
      });
    });
  });

  // Checkout
  const checkoutBtn = document.getElementById("checkoutBtn");
  const checkoutModal = document.getElementById("checkoutModal");
  const closeCheckoutBtn = document.getElementById("closeCheckoutBtn");
  const backToCartBtn = document.getElementById("backToCartBtn");
  const placeBookingBtn = document.getElementById("placeBookingBtn");
  const checkoutFormWrap = document.getElementById("checkoutFormWrap");
  const checkoutSuccess = document.getElementById("checkoutSuccess");
  const closeSuccessBtn = document.getElementById("closeSuccessBtn");

  checkoutBtn?.addEventListener("click", () => {
    if(!loadCart().length) return;
    if(checkoutFormWrap) checkoutFormWrap.style.display = "grid";
    checkoutSuccess?.classList.remove("open");
    openModal(checkoutModal);
  });
  closeCheckoutBtn?.addEventListener("click", ()=>closeModal(checkoutModal));
  backToCartBtn?.addEventListener("click", ()=>{
    closeModal(checkoutModal);
    openModal(cartModal);
  });

  placeBookingBtn?.addEventListener("click", async (e) => {
    e.preventDefault();
    const name = document.getElementById("name")?.value.trim();
    const email = document.getElementById("email")?.value.trim();
    if(!name || !email){
      showToast("Please enter your name and email.");
      return;
    }

    const cart = loadCart();
    const order = {
      id: "order_" + Date.now(),
      createdAt: new Date().toISOString(),
      customer: {
        name,
        email,
        phone: document.getElementById("phone")?.value.trim() || "",
        notes: document.getElementById("notes")?.value.trim() || ""
      },
      items: cart,
      totals: {
        subtotal: cartSubtotal(cart),
        fees: 0,
        total: cartSubtotal(cart)
      }
    };

    // local demo log
    const orders = JSON.parse(localStorage.getItem(ORDERS_KEY) || "[]");
    orders.push(order);
    localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));

    // 1) Netlify Forms
    try{
      await submitNetlifyForm("booking", {
        order_id: order.id,
        createdAt: order.createdAt,
        name: order.customer.name,
        email: order.customer.email,
        phone: order.customer.phone,
        notes: order.customer.notes,
        items: order.items,
        totals: order.totals
      });
    }catch(err){ console.warn(err); }

    // 2) Google Sheets via Netlify Function
    try{
      await fetch("/.netlify/functions/order-to-sheets", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(order)
      });
    }catch(err){ console.warn(err); }

    saveCart([]);
    renderCart();

    if(checkoutFormWrap) checkoutFormWrap.style.display = "none";
    checkoutSuccess?.classList.add("open");
    showToast("Booking placed!");
  });

  closeSuccessBtn?.addEventListener("click", ()=>closeModal(checkoutModal));

  renderCart();
}

document.addEventListener("DOMContentLoaded", wireUp);
