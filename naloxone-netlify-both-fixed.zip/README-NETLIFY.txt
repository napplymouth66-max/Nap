
NETLIFY DEPLOY (Drag & Drop)
1) Unzip this folder locally
2) In Netlify → Sites → drag the *contents* of this folder
3) Done.

FORMS
- Contact form: name="contact"
- Kit request: name="kit-request"
- Volunteer: name="volunteer"
- Newsletter: name="newsletter"
- Booking checkout: name="booking" (submitted via JS)

Enable email notifications:
Netlify Dashboard → Site → Forms → Notifications.

GOOGLE SHEETS (Bookings)
This uses Google Apps Script as a webhook.

1) Create a Google Sheet
2) Extensions → Apps Script
3) Paste this in Code.gs, Save:

function doPost(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheets()[0];
  var data = {};
  try { data = JSON.parse(e.postData.contents || "{}"); } catch (err) {}
  sh.appendRow([
    new Date(),
    data.id || "",
    (data.customer && data.customer.name) || "",
    (data.customer && data.customer.email) || "",
    (data.customer && data.customer.phone) || "",
    (data.customer && data.customer.notes) || "",
    JSON.stringify(data.items || []),
    JSON.stringify(data.totals || {})
  ]);
  return ContentService.createTextOutput(JSON.stringify({ok:true}))
    .setMimeType(ContentService.MimeType.JSON);
}

4) Deploy → New deployment → Web app
   - Execute as: Me
   - Who has access: Anyone
   Copy the Web app URL.

5) Netlify → Site settings → Environment variables
   Add: GOOGLE_SHEETS_WEBHOOK_URL = <your web app URL>

6) Redeploy.

